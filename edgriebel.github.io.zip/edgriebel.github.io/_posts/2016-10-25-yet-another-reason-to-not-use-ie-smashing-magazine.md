---
id: 158
title: 'Yet another reason to not use IE --- Smashing Magazine'
date: 2016-10-25T11:55:10+00:00
author: edgriebel
guid: http://www.edgriebel.com/?p=158
permalink: /yet-another-reason-to-not-use-ie-smashing-magazine/
categories:
  - Uncategorized
tags:
  - ie
---
This must be reason #84 at this point to use anything (even Opera) instead of IE...<!--more-->

{:right: style="float: right" width="150px"}
![ie6](../wp-content/uploads/2016/10/IE6-150x150.png)\\
*"Microsoft Standards"*
{:right}
> 512 MAGICAL BYTES: This is, hands down,
> one of the strangest quirks I have ever encountered in web development. 
> You must ensure that the total size of your 404.html page is greater than 512 bytes, because if it isn’t, Internet Explorer will disregard it and show a generic browser 404 page instead. When I finally figured this out, I had to crack open a beer to cope with the amount of time it took.

Source:
[S(GH)PA: The Single-Page App Hack For GitHub Pages – Smashing Magazine](https://www.smashingmagazine.com/2016/08/sghpa-single-page-app-hack-github-pages/#512-magical-bytes)

