---
id: 136
title: Big Numbers
date: 2016-06-15T11:42:07+00:00
author: edgriebel
guid: http://www.edgriebel.com/?p=136
permalink: /big-numbers/
categories:
  - Uncategorized
tags:
  - java
---
<a href="http://turnoff.us/geek/big-numbers/"><img class="size-full aligncenter" src="http://www.edgriebel.com/wp-content/uploads/2016/06/big-numbers.png" /></a>
Source: <em><a href="http://turnoff.us/geek/big-numbers">Big Numbers</a></em>

The easiest way to start a flamewar....