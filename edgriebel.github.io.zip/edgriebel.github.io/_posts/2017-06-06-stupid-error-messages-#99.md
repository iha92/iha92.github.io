---
title: Stupid Error Messages #99
---

```
C:> net stop cntlm
The Cntlm Authentication Proxy service is not started.

More help is available by typing NET HELPMSG 3521.

C:> net helpmsg 3521

The *** service is not started.

C:>
```
