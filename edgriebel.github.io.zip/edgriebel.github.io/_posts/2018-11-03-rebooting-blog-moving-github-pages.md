---
categories: blog
title: Rebooting Blog and Moving to Github Pages
---
I'm taking the plunge and finally finishing up moving this off of Dreamhost and onto Github pages. 
It's been "staged" on github for a while now, finally allocated time to getting it fully off dreamhost (and will save $10/mo).
HTTPS is not working yet, some extra config needs to be done on github's side. 
It was pretty easy on Dreamhost, just click a box and it automatically set up a LetsEncrypt cert for your domain.
I'm just happy that www redirection works :-)

I'm going to be moving content that's been in draft form for "a while" (a _long_ while in some cases), I'll mark them the date I published them as the as-of date. If I'm disciplined enough I'll add the original date in the text.

At some point I'm going to go on a theme hunt again. 
I have to add an 'about' page with my resume and contact info, and find a template that shows the title and date at the top of a post.
I've added them in myself to an old verison of the website, but then you can't auto-update anymore (or at least I haven't figured out how to do it yet).
