---
id: 115
title: CareerBuilder listings used as Phishing platform
date: 2015-04-30T12:48:39+00:00
author: edgriebel
guid: http://www.edgriebel.com/?p=115
permalink: /careerbuilder-listings-used-as-phishing-platform/
categories:
  - Uncategorized
---
{:left: style="float: left" width="250px"}
![phished](../wp-content/uploads/2015/04/security-phishing-100314300-primary.idge_.jpg){:width="250px"}
{:left:}
Researchers at Proofpoint recently discovered a Phishing campaign that originated from select job postings on CareerBuilder.

Companies seeking applicants allow them to send resumes. Someone figured out how to upload files that install viruses in a staged attack. The brilliant part of it is that most companies using CareerBuilder will also whitelist attachments from CareerBuilder, and are expecting to get attachments from unknown people, making a (spear-)phishing attack that much easier.

Source: 
[CareerBuilder listings used as Phishing platform | CSO Online](http://www.csoonline.com/article/2916524/social-engineering/careerbuilder-listings-used-as-phishing-platform.html)
