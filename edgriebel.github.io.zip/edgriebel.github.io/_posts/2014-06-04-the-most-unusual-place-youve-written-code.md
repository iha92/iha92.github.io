---
id: 55
title: 'The most unusual place you&#8217;ve written code'
date: 2014-06-04T09:44:48+00:00
author: edgriebel
guid: http://www.edgriebel.com/?p=55
permalink: /the-most-unusual-place-youve-written-code/
categories:
  - Uncategorized
tags:
  - Axeda
---
<a title="This piece" href="http://blogs.sas.com/content/publishing/2014/06/03/the-most-unusual-place-youve-had-sas/" target="_blank">This piece</a> asks about the most unusual place you've written code. My most unusual place was in PowerPoint at FL280 and in a Lincoln.<!--more-->

<a href="http://www.edgriebel.com/wp-content/uploads/2014/06/embrarer-rj145.jpg"><img class="alignright size-medium wp-image-60" src="http://www.edgriebel.com/wp-content/uploads/2014/06/embrarer-rj145-300x168.jpg" alt="Embraer Regional Jet" width="300" height="168" /></a>
I had an interview assignment for <a title="Axeda" href="http://www.axeda.com" target="_blank">Axeda</a> where I had to create program stubs to do <i>mumble</i> and create slides to support a presentation to devs, architects, and the CTO.

I was given about 24 hours notice that there was this assignment including time flying to the Foxboro office. The program was done the day before but I wasn't happy with it nor the presentation, so with my netbook in hand (small <a title="Asus 1201N" href="http://www.asus.com/Notebooks_Ultrabooks/Eee_PC_1201N_Seashell/" target="_blank">Asus 1201N</a>) I tweaked the code and redid my presentation on the plane flight and livery ride to the office. The presentation must have been good because I was there for three years. My trip was 14 hours door-to-door for about 4 hours of interviews because of a transfer each way to/from Logan, so I did have plenty of time for coding.
