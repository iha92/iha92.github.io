---
id: 100
title: Funny Oracle error message
date: 2015-02-04T15:56:40+00:00
author: edgriebel
guid: http://www.edgriebel.com/?p=100
permalink: /funny-oracle-error-message/
categories:
  - Uncategorized
tags:
  - Oracle
  - wtf
---
Oracle has an "Early Adopter" version of <a href="http://www.oracle.com/technetwork/developer-tools/sql-developer/downloads/index.html" target="_blank">SQL Developer</a>, a tool I have "become accustomed to" at a prior job where they couldn't/wouldn't pay for developers to have the superior <a href="http://software.dell.com/solutions/database-development-and-management/" target="_blank">TOAD</a> SQL product. One of the caveats they list on the download page is that it only runs under JDK 8, so I got a chuckle out of this error message.

Note that JDK 7 end-of-life (called "end of public updates", meaning for a big $$ support contract you can still get updates) has been <a title="Java 7 Product Roadmap" href="http://www.oracle.com/technetwork/java/eol-135779.html" target="_blank">announced for April 2015 </a>by...Oracle.

<a href="http://www.edgriebel.com/wp-content/uploads/2015/02/oracle-1.8-error.png"><img class=" wp-image-101 size-full aligncenter" src="http://www.edgriebel.com/wp-content/uploads/2015/02/oracle-1.8-error.png" alt="oracle-1.8-error" width="549" height="247" /></a>