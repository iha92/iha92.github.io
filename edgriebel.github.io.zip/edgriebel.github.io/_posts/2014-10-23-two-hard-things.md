---
id: 86
title: 'Two Hard Things&#8230;'
date: 2014-10-23T08:19:17+00:00
author: edgriebel
guid: http://www.edgriebel.com/?p=86
permalink: /two-hard-things/
categories:
  - Uncategorized
---
<blockquote>There are only two hard things in Computer Science: cache invalidation and naming things.

-- Phil Karlton
<!--more-->

Long a favorite saying of mine, one for which I couldn't find a satisfactory URL.

There is also a variation on this that says there are two hard things in computer science: cache invalidation, naming things, and off-by-one errors.

http://martinfowler.com/bliki/TwoHardThings.html</blockquote>