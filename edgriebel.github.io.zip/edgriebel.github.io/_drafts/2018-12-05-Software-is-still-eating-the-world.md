---
title: "Software Is STILL Eating the World"
---

https://a16z.com/2016/08/20/why-software-is-eating-the-world/
