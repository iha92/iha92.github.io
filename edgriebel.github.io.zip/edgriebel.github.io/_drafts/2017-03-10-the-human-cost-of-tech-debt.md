---
layout: post
tags: 
 - tech-debt
---
> Editorial Note: I originally wrote this post for the Infragistics blog.  Head over to their site and check out the original.  While you're there, have a look at the other blog authors and their product offering. If you're not already familiar with the concept of technical debt, it's worth becoming familiar with it.  I say ...

Source: [The Human Cost of Tech Debt --- DaedTech](http://www.infragistics.com/community/blogs/erikdietrich/archive/2016/06/29/the-human-cost-of-tech-debt.aspx)

