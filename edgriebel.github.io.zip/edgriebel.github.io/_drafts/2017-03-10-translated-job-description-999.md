---
tag: funny
template: post
---
<div style="float: right" markdown="1">
![sweatshop](../wp-content/uploads/2017/01/open-plan-150x150.jpg){:width="150px"}
</div>
> We are seeking mid and senior level C++ developers with excellent computer science and programming skills. Must have strong core fundamental knowledge of the C++ language and exceptional problem solving abilities. Multiple full time openings available within various teams. The work environment is fast paced, energetic and you’ll be working on exciting projects and on cutting-edge technologies.

**Translation**
excellent CS and programming skills = our interviews are now as hard as Google because we’ve hired some real duds in the past

must have exceptional problem solving skills = our codebase is old and crappy and full of bugs so bad that people have walked out

multiple full time openings = a lot of people just left because we took a calculated risk at low-balling people’s year-end bonuses

within various teams = this low-balling happened across all of development

work environment is fast paced = your workload will be Sisyphean and your priorities will change weekly/daily

and energetic = you’ll be working in an open plan office with peers that always put in 60-80 hour weeks because they haven't learned the power of "no"

you’ll be working on exciting projects = you’ll be working on multiple high-vis/high-pressure Agile teams simultaneously

cutting-edge technologies = our tech stack evolves on a quarterly if not monthly basis, which compensates for working in C++
