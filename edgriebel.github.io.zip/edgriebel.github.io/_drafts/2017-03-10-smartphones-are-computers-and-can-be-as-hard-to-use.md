---
layout: post
tag: human-computer-interaction
---
My father-in-law got a new Galaxy S3, his first smartphone after having had a "feature phone" for years.

