---
layout: post

---

> Get a sense of estimating the skills, knowledge of users, and developers. Invest adequately in the understanding of the existing codebase.

Source: [12 Factors and Beyond in Java](https://dzone.com/articles/12-factors-and-beyond-in-java)
