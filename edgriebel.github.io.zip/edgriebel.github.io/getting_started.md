# First, load appropriate packages
* Ruby if not installed (_command to follow_)
* gem install jekyll bundler
* bundle install
* jekyll # check that jekyll works
* jekyll build
* jekyll s --port _yourport_

