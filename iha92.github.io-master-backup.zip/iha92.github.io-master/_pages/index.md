---
permalink: /
layout: home
author_profile: true
excerpt: Just another Jekyll-based programming blog
---
