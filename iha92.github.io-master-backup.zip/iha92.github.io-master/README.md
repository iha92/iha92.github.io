# [iha92.github.io](https://iha92.github.io/)

## CONTRIBUTE
### 1. Run locally
```
$ git clone https://github.com/iha92/iha92.github.io.git
$ cd iha92.github.io
$ bundle
$ bundle exec jekyll serve      # Serve at http://127.0.0.1:4000
```
### 2. Theme help
Minimal Mistakes Jekyll theme is used - [homepage](https://mmistakes.github.io/minimal-mistakes/), [repo](https://github.com/mmistakes/minimal-mistakes).

## TODO
- [ ] create lots of posts, trying all includes, layouts etc
- [ ] create lots of options for archive, search, homepage, about
- [ ] theme everything
- [ ] Prose/ siteleaf
- [ ] balance prose and template
